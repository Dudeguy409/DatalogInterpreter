/*
 * Tuple.cpp
 *
 *  Created on: Jul 22, 2014
 *      Author: davidsoa
 */

#include "Tuple.h"

Tuple::Tuple() {
	// TODO Auto-generated constructor stub

}

Tuple::~Tuple() {
	// TODO Auto-generated destructor stub
}

