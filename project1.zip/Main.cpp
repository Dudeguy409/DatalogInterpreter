/*
 * Main.cpp
 *
 *  Created on: Jun 27, 2014
 *      Author: davidsoa
 */

#include "Main.h"
#include <vector>
#include "Token.h"
#include <string>
#include <iostream>
#include <fstream>
#include "Tokenizer.h"

using namespace std;

int main(int argc, char* argv[]) {

	Tokenizer t(argv[1]);

	vector<Token> v = t.getTokens();

	ofstream out;
	try {

		out.open(argv[2]);

	} catch (int e) {
		cout << "The output file path was not valid.\n";
	}
	//cout << "size of v: " << v.size() << "\n";
	for (int i = 0; i < v.size(); i++)
		out << v[i].toString();

	if (!t.getIsInvalid())
		out << "Total Tokens = " << (v.size() - 1) << "\n";

	return 0;
}
