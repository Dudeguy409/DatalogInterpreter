/*
 * Main.h
 *
 *  Created on: Jun 27, 2014
 *      Author: davidsoa
 */

#ifndef MAIN_H_
#define MAIN_H_

using namespace std;

class Main {
	int main(int argc, char* argv[]);

};

#endif /* MAIN_H_ */
