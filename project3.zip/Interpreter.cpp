/*
 * Interpreter.cpp
 *
 *  Created on: Jul 22, 2014
 *      Author: davidsoa
 */

using namespace std;
#include "Interpreter.h"
#include <iostream>
#include <map>
#include <sstream>

Interpreter::Interpreter() {
	// TODO Auto-generated constructor stub
}

Interpreter::~Interpreter() {
	// TODO Auto-generated destructor stub
}

Interpreter::Interpreter(DatalogProgram & data) {
	database = Database();
	rawData = data;

	processSchemes();

	processFacts();

	processRules();

	result = processQueries();
	//result = database.toString();
}

void Interpreter::processSchemes() {
	vector<Predicate> schemes = rawData.getSchemes();

	for (Predicate scheme : schemes) {
		string tempName = scheme.getName();
		vector<Parameter> schemeParams = scheme.getParamList();
		Scheme schemeToAdd = buildScheme(schemeParams);
		Relation relation = Relation(tempName, schemeToAdd);
		database.addRelation(tempName, relation);
	}
}

void Interpreter::processFacts() {
	vector<Predicate> facts = rawData.getFacts();

	for (Predicate fact : facts) {
		vector<Parameter> factParams = fact.getParamList();
		Tuple tuple = buildTuple(factParams);
		string name = fact.getName();
		database.addTuple(name, tuple);
	}
}

void Interpreter::processRules() {

}

string Interpreter::processQueries() {
	vector<Predicate> queries = rawData.getQueries();
	ostringstream rslt;
	for (Predicate query : queries) {
		rslt << processQuery(query);
	}
	return rslt.str();
}

string Interpreter::processQuery(Predicate & query) {
	//Relation origRelation = database.getRelation(name);
	ostringstream rslt;
	string name = query.getName();
	Relation destRelation = database.getRelation(name);
	vector<Parameter> queryParams = query.getParamList();
	map<string, vector<int>> identMap = map<string, vector<int>>();
	vector<string> orderedIDs = vector<string>();

	destRelation = sortQuery(queryParams, identMap, destRelation, orderedIDs);

	destRelation = handleQueryMatchSelect(destRelation, identMap);
	rslt << name << "(" << destRelation.getScheme().toString() << ")? ";
	destRelation = handleQueryProjection(destRelation, identMap, orderedIDs);

	rslt << destRelation.toQueryResultString();
	return rslt.str();
}

Relation Interpreter::sortQuery(vector<Parameter> & queryParams,
		map<string, vector<int>> & identMap, Relation & relation,
		vector<string> & orderedIDs) {
	if (queryParams.size() != relation.getScheme().size()) {
		throw "one of the queries did not have the correct number of parameters.";
	}

	for (int i = 0; i < queryParams.size(); i++) {
		string value = queryParams[i].getValue();
		if (queryParams[i].isID()) {
			relation = relation.rename(i, queryParams[i].getValue());
			//if pair doesn't exist, creates a pair with new vector
			if (identMap.count(value) == 0) {
				orderedIDs.push_back(value);
				identMap[value] = vector<int>();
			}
			identMap[value].push_back(i);
		} else {
			ostringstream ss;
			ss << "'" << queryParams[i].getValue() << "'";
			relation = relation.rename(i, ss.str());
			relation = relation.select(i, value);
		}
	}
	return relation;
}

Relation Interpreter::handleQueryMatchSelect(Relation & destRelation,
		map<string, vector<int>> & identMap) {
	for (pair<string, vector<int>> p : identMap) {
		if (p.second.size() > 1) {
			destRelation = destRelation.select(p.second);
		}
	}
	return destRelation;
}

Relation Interpreter::handleQueryProjection(Relation & destRelation,
		map<string, vector<int>> & identMap, vector<string> orderedIDs) {

	vector<int> positionsToProject = vector<int>();
	for (int i = 0; i < destRelation.getScheme().size(); i++) {
		positionsToProject.push_back(-1);
	}

	int varCount = 0;
	for (string id : orderedIDs) {
		positionsToProject[identMap[id][0]] = varCount;
		varCount++;
	}

	return destRelation.project(positionsToProject, varCount);
}

Scheme Interpreter::buildScheme(vector<Parameter> & predParams) {
	vector<string> attributes = vector<string>();
	for (int i = 0; i < predParams.size(); i++) {
		if (!predParams[i].isID())
			throw "Error building scheme:  There can be only identifiers in a scheme.";
		attributes.push_back(predParams[i].getValue());
	}
	return Scheme(attributes);
}

Tuple Interpreter::buildTuple(vector<Parameter> & predParams) {
	Tuple tuple = Tuple();

	for (int i = 0; i < predParams.size(); i++) {
		if (predParams[i].isID()) {
			throw "Error inserting one of the facts in the database:  There can be no identifiers in a scheme.";
		}
		tuple.push_back(predParams[i].getValue());
	}
	return tuple;
}

string Interpreter::getResult() {
	return result;
}

